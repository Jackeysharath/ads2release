import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-seltemplate',
  templateUrl: './seltemplate.component.html',
  styleUrls: ['./seltemplate.component.css']
})
export class SeltemplateComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {
  }
  getTempleteType(){
    this.route.navigate(['./seltemplatetype']);
  }

}
