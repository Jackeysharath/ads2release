import { Component, OnInit } from '@angular/core';
import { AfterViewInit } from "@angular/core";
import { Router } from "@angular/router";
declare var jquery: any;
declare var $ :any;
declare var Modernizr :any;

@Component({
  selector: 'app-compose',
  templateUrl: './compose.component.html',
  styleUrls: ['./compose.component.css']
})
export class ComposeComponent implements OnInit,AfterViewInit {

  constructor(private route:Router) { }

  ngOnInit() {
  }
  ngAfterViewInit(){
    $('#edit-header').on('froalaEditor.contentChanged froalaEditor.initialized', function (e, editor) {
      $('#preview-header').html(editor.html.get());
    }).froalaEditor({
  toolbarButtons: ['bold', 'italic', 'underline', 'fontFamily', 'fontSize', 'color', 'align']
});
$('#edit-body').on('froalaEditor.contentChanged froalaEditor.initialized', function (e, editor) {
      $('#preview-body').html(editor.html.get());
    }).froalaEditor({
  toolbarButtons: ['bold', 'italic', 'underline', 'fontFamily', 'fontSize', 'color', 'align']
});
$('#edit-footer').on('froalaEditor.contentChanged froalaEditor.initialized', function (e, editor) {
      $('#preview-footer').html(editor.html.get());
    }).froalaEditor({
  toolbarButtons: ['bold', 'italic', 'underline', 'fontFamily', 'fontSize', 'color', 'align']
});

//add color picker for footer content
if (Modernizr.inputtypes.color) {
$(".pickerfooter").css("display", 'inline-block');
var d = document.getElementById('colorpicker-footer');
d.addEventListener('change', function(e) {
  //d.innerHTML = c.value;
  // var color = d.value;
  var color = "green";
  $("#edit-footer .fr-element").css("background-color", color);
  $("#preview-footer").css("background-color", color);
  }, false);
}
//add color picker for body content
if (Modernizr.inputtypes.color) {
$(".pickerbody").css("display", 'inline-block');
var b = document.getElementById('colorpicker-body');
b.addEventListener('change', function(c) {
  //d.innerHTML = c.value;
  // var color = b.value;
  var color = "red";
  $("#edit-body .fr-element").css("background-color", color);
  $("#preview-body").css("background-color", color);
  }, false);
}
//add color picker for header content
if (Modernizr.inputtypes.color) {
$(".pickerheader").css("display", 'inline-block');
var f = document.getElementById('colorpicker-header');
f.addEventListener('change', function(g) {
  //d.innerHTML = c.value;
  
  // var color = f.value;
  var color = "blue";
  $("#edit-header .fr-element").css("background-color", color);
  $("#preview-header").css("background-color", color);
  }, false);
}

  }
  checkout(){
    this.route.navigate(['./login']);
  }

}
