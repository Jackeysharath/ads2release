import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-categorysel',
  templateUrl: './categorysel.component.html',
  styleUrls: ['./categorysel.component.css']
})
export class CategoryselComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {
  }
  getNewspapers(){

  }
  getEditions(){

  }
  getNewpaperBasedonEdition(){}
  getEditonBasedonNewspaper(){}
  getCategoriesOnSelection(){

  }
  selectCategory(){
    this.route.navigate(['./selectedcat']);
  }

}
