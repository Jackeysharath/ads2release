import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepayment',
  templateUrl: './prepayment.component.html',
  styleUrls: ['./prepayment.component.css']
})
export class PrepaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
