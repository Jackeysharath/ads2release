import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seltemplatetype',
  templateUrl: './seltemplatetype.component.html',
  styleUrls: ['./seltemplatetype.component.css']
})
export class SeltemplatetypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
