import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingsummary',
  templateUrl: './bookingsummary.component.html',
  styleUrls: ['./bookingsummary.component.css']
})
export class BookingsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
