import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seltemplate',
  templateUrl: './seltemplate.component.html',
  styleUrls: ['./seltemplate.component.css']
})
export class SeltemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
