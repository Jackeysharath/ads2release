import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categorysel',
  templateUrl: './categorysel.component.html',
  styleUrls: ['./categorysel.component.css']
})
export class CategoryselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
