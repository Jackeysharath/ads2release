import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catselected',
  templateUrl: './catselected.component.html',
  styleUrls: ['./catselected.component.css']
})
export class CatselectedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
