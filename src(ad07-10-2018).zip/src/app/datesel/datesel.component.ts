import { Component, OnInit , ElementRef, ViewChild,AfterViewInit} from '@angular/core';
import { Router } from "@angular/router";
declare var multiDatesPicker: any;
declare var jquery: any;
declare var $ :any;
declare var Modernizr :any;
@Component({
  selector: 'app-datesel',
  templateUrl: './datesel.component.html',
  styleUrls: ['./datesel.component.css']
})

export class DateselComponent implements OnInit,AfterViewInit {
  @ViewChild('mdpdemo') mdpdemo: ElementRef;
  @ViewChild('altField') altField: ElementRef;
  
  constructor(private route:Router) { }

  ngOnInit() {
  }
  ngAfterViewInit(){
    let altField=this.altField.nativeElement
    $('#mdp-demo').multiDatesPicker({
			altField: "#altField",
		  maxPicks: 3
		});
  }
  getCompose(){
    this.route.navigate(['./compose']);
  }

}
